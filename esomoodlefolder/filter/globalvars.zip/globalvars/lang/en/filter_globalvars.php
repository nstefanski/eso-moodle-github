<?php // $Id$
// Language string for filter/globalvars.

$string['filtername'] = 'Global Variables';